package org.empresa.restsunat.model.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.empresa.restsunat.model.Producto;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ProductoDao {

	@PersistenceContext
    private EntityManager entityManager;
     
	public List<Producto> encuentraProductosPorCatalogado(Boolean catalogado) {
        if (catalogado == null) throw new IllegalArgumentException("El producto tiene que estar catalogado");
        TypedQuery<Producto> q = entityManager.createQuery("SELECT o FROM Producto AS o WHERE o.catalogado = :catalogado", Producto.class);
        q.setParameter("catalogado", catalogado);
        return q.getResultList();
    }
	
	public long cuentaProductos() {
        return entityManager.createQuery("SELECT COUNT(o) FROM Producto o", Long.class).getSingleResult();
    }
	
	public List<Producto> encuentraTodosProductos() {
        return entityManager.createQuery("SELECT o FROM Producto o", Producto.class).getResultList();
    }

	public Producto encuentraProducto(Long id_producto) {
        if (id_producto == null) return null;
        return entityManager.find(Producto.class, id_producto);
    }

	public List<Producto> encuentraEntradasProductos(int primerResultado, int maximoResultado) {
        return entityManager.createQuery("SELECT o FROM Producto o", Producto.class).setFirstResult(primerResultado).setMaxResults(maximoResultado).getResultList();
    }
	
	@SuppressWarnings("unchecked")
	public List<Producto> encuentraEntradasProductos(Producto producto) {
		Query consulta = null;
		if (producto.getCategoria() != null) {
			consulta = entityManager.createQuery("SELECT o FROM Producto o WHERE o.nombre like :nombre and o.categoria = :categoria", Producto.class);
			consulta.setParameter("nombre", "%" + producto.getNombre() + "%");
			consulta.setParameter("categoria", producto.getCategoria());
		}
		else {
			consulta = entityManager.createQuery("SELECT o FROM Producto o WHERE o.nombre like :nombre", Producto.class);
			consulta.setParameter("nombre", "%" + producto.getNombre() + "%");
		}
        return consulta.getResultList();
    }

	
	public void persist(Producto producto) {
        this.entityManager.persist(producto);
    }

	public void remove(Producto producto) {
        if (this.entityManager.contains(producto)) {
            this.entityManager.remove(producto);
        } else {
            Producto agregado = encuentraProducto(producto.getId_producto());
            this.entityManager.remove(agregado);
        }
    }

	public void flush() {
        this.entityManager.flush();
    }

	public void clear() {
        this.entityManager.clear();
    }

	public Producto merge(Producto producto) {
        Producto merged = this.entityManager.merge(producto);
        this.entityManager.flush();
        return merged;
    }



}
