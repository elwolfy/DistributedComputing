package org.empresa.restsunat.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.empresa.restsunat.model.Producto;
import org.empresa.restsunat.model.dao.ProductoDao;
@Service
@Transactional
public class ProductoService {

	@Autowired
	private ProductoDao productoDao;

	
	
	public List<Producto> obtenerCatalogadosProductos() {
		return productoDao.encuentraProductosPorCatalogado(true);
	}

	public long contarTodosProductos() {
        return productoDao.cuentaProductos();
    }

	public void eliminarProducto(Producto producto) {
		productoDao.remove(producto);
    }

	public Producto encontrarProducto(Long id_producto) {
         Producto producto = productoDao.encuentraProducto(id_producto);
         if (producto == null) {
        	 throw new RuntimeException();
         }
         return producto;
    }

	public List<Producto> encuentraTodosProductos() {
        return productoDao.encuentraTodosProductos();
    }

	public List<Producto> encuentraEntradasProductos(int primerResultado, int maximoResultado) {
        return productoDao.encuentraEntradasProductos(primerResultado, maximoResultado);
    }

	public void guardarProduct(Producto producto) {	
		
		productoDao.persist(producto);
    }

	public Producto actualizaProduct(Producto producto) {
        return productoDao.merge(producto);
    }

	public List<Producto> encuentraProductos(Producto producto) {
		return productoDao.encuentraEntradasProductos(producto);
	}
}
