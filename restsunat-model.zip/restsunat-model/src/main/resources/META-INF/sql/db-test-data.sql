insert into producto (id_producto, nombre, descripcion, catalogado, ruta_imagen, precio, version, categoria, unidad_medida) values (default, 'Azucar La Paisana', 'Azucar natural de las mejores chachras', true, 'c:/img/1.jpg', 2.5, 1, 'Comestibles','Unidad' )

insert into producto (id_producto, nombre, descripcion, catalogado, ruta_imagen, precio, version, categoria, unidad_medida) values (default, 'Zapatilla Azul Adidas', 'Tallas 40, 41, 42', true, 'c:/img/2.jpg', 100.5, 1, 'Zapatillas','Unidad' )
insert into producto (id_producto, nombre, descripcion, catalogado, ruta_imagen, precio, version, categoria, unidad_medida) values (default, 'Pantalon Jean Azul Pierre', 'Todos los tamaños', true, 'c:/img/3.jpg', 185.00, 1, 'Ropa','Unidad' )
insert into producto (id_producto, nombre, descripcion, catalogado, ruta_imagen, precio, version, categoria, unidad_medida) values (default, 'Ceviche de Mariscos', 'Mariscos frescos del mar', true, 'c:/img/4.jpg', 15, 1, 'Comestibles','Kg.' )

