package org.empresa.restsunat;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import org.empresa.restsunat.model.Producto;

@Component
public class ValidadorBusquedaProducto implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Producto.class.isAssignableFrom(clazz);  
	}

	@Override
	public void validate(Object target, Errors errors) {
		Producto producto = (Producto) target;
		String nombre = producto.getNombre();
        if (!StringUtils.hasLength(nombre) && (producto.getCategoria() == null)) {
            errors.rejectValue("nombre", "required", "Tanto nombre y categoria son requeridos");
        } else if (producto.getCategoria() == null && nombre.trim().length() < 3) {
            errors.rejectValue("nombre", "tooShort", "Ingresar por lo menos 3 caracteres");
        }

	}

}
