package org.empresa.restsunat.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import org.empresa.restsunat.beans.MessageRestBean;
import org.empresa.restsunat.model.Producto;
import org.empresa.restsunat.model.service.ProductoService;

@Controller
@RequestMapping("/api")
public class ProductoRestController {

	@Autowired
	ProductoService productoService;

	public ProductoRestController(){
    	org.hsqldb.util.DatabaseManagerSwing.main(new String[] { "--url", "jdbc:hsqldb:mem:sunatrest", "--noexit" });		
	}
	
	@RequestMapping(value = "/productos/{productoId}")
	@ResponseBody
	public Producto getProducto(@PathVariable("productoId") Long productoId) {
		Producto producto = productoService.encontrarProducto(productoId);
		return producto;
	}
	
	@RequestMapping(value = "/productos")
	@ResponseBody
	public List<Producto> getProductos() { 
		return productoService.encuentraTodosProductos();
	}
	
	@ExceptionHandler({SQLException.class,DataAccessException.class})
	public ResponseEntity<MessageRestBean> handleDatabaseErrors() {
	   
	  return new ResponseEntity<MessageRestBean>(new MessageRestBean("Error en Base de Datos", "DBERR"), HttpStatus.INTERNAL_SERVER_ERROR);
	  
	}
	
}
